<footer>
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> Photographer's Portfolio. All rights reserved.</p>
        <div class="social-links">
            <a href="https://facebook.com" target="_blank">Facebook</a>
            <a href="https://twitter.com" target="_blank">Twitter</a>
            <a href="https://instagram.com" target="_blank">Instagram</a>
        </div>
    </div>
</footer>
</body>
</html>
