<?php
include('header.php'); // Include header
include('db.php'); // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category = $_POST['category'];
    $image = $_FILES['image']['name'];

    // File upload logic
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/$image");

    $query = "INSERT INTO gallery (category, image) VALUES ('$category', '$image')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<p>Image uploaded successfully.</p>";
    } else {
        echo "<p>Error: " . mysqli_error($conn) . "</p>";
    }
}

$gallery = mysqli_query($conn, "SELECT * FROM gallery");
?>

<div class="manage-gallery">
    <h1>Manage Gallery</h1>
    <form method="POST" enctype="multipart/form-data">
        <label for="category">Category:</label>
        <input type="text" id="category" name="category" required>

        <label for="image">Upload Image:</label>
        <input type="file" id="image" name="image" required>

        <button type="submit">Add to Gallery</button>
    </form>

    <h2>Gallery</h2>
    <ul>
        <?php while ($row = mysqli_fetch_assoc($gallery)) { ?>
            <li><?php echo $row['category']; ?> - <img src="uploads/<?php echo $row['image']; ?>" alt="" width="100"></li>
        <?php } ?>
    </ul>
</div>

<?php
include('footer.php'); // Include footer
?>
