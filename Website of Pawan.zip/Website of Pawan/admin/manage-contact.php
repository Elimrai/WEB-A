<?php
include('header.php'); // Include header
include('db.php'); // Database connection

$contacts = mysqli_query($conn, "SELECT * FROM contacts ORDER BY created_at DESC");
?>

<div class="manage-contact">
    <h1>Manage Contact Messages</h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Received At</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($contacts)) { ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['message']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php
include('footer.php'); // Include footer
?>
