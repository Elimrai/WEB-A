<?php
include('header.php'); // Include header
?>

<div class="dashboard">
    <h1>Welcome to the Admin Dashboard</h1>
    <div class="links">
        <a href="manage-content.php">Manage Content</a>
        <a href="manage-gallery.php">Manage Gallery</a>
        <a href="manage-portfolio.php">Manage Portfolio</a>
        <a href="manage-contact.php">Manage Contacts</a>
    </div>
</div>

<style>
    .dashboard {
        text-align: center;
        margin-top: 50px;
    }
    .links a {
        margin: 10px;
        padding: 10px 20px;
        display: inline-block;
        background: #007BFF;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }
    .links a:hover {
        background: #0056b3;
    }
</style>

<?php
include('footer.php'); // Include footer
?>
