<?php
include('header.php'); // Include header
include('db.php'); // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $page = $_POST['page_name'];
    $content = $_POST['content'];

    $query = "INSERT INTO pages_content (page_name, content) VALUES ('$page', '$content') 
              ON DUPLICATE KEY UPDATE content='$content'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<p>Content updated successfully.</p>";
    } else {
        echo "<p>Error: " . mysqli_error($conn) . "</p>";
    }
}

$pages = mysqli_query($conn, "SELECT * FROM pages_content");
?>

<div class="manage-content">
    <h1>Manage Page Content</h1>
    <form method="POST">
        <label for="page_name">Page Name:</label>
        <input type="text" id="page_name" name="page_name" required>

        <label for="content">Content:</label>
        <textarea id="content" name="content" required></textarea>

        <button type="submit">Save Content</button>
    </form>

    <h2>Existing Content</h2>
    <ul>
        <?php while ($row = mysqli_fetch_assoc($pages)) { ?>
            <li><strong><?php echo $row['page_name']; ?>:</strong> <?php echo $row['content']; ?></li>
        <?php } ?>
    </ul>
</div>

<?php
include('footer.php'); // Include footer
?>
