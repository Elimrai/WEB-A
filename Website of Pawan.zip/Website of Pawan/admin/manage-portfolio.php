<?php
include('header.php'); // Include header
include('db.php'); // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];

    // File upload logic
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/$image");

    $query = "INSERT INTO portfolio (title, description, image) VALUES ('$title', '$description', '$image')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<p>Portfolio item added successfully.</p>";
    } else {
        echo "<p>Error: " . mysqli_error($conn) . "</p>";
    }
}

$portfolio = mysqli_query($conn, "SELECT * FROM portfolio");
?>

<div class="manage-portfolio">
    <h1>Manage Portfolio</h1>
    <form method="POST" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>

        <label for="image">Upload Image:</label>
        <input type="file" id="image" name="image" required>

        <button type="submit">Add to Portfolio</button>
    </form>

    <h2>Portfolio</h2>
    <ul>
        <?php while ($row = mysqli_fetch_assoc($portfolio)) { ?>
            <li><?php echo $row['title']; ?> - <img src="uploads/<?php echo $row['image']; ?>" alt="" width="100"></li>
        <?php } ?>
    </ul>
</div>

<?php
include('footer.php'); // Include footer
?>
