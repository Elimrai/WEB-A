<?php include('db_config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/filter.js"></script>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <section class="gallery">
        <h1>Photo Gallery</h1>
        <div class="filter-menu">
            <button onclick="filterGallery('all')">All</button>
            <button onclick="filterGallery('Nature')">Nature</button>
            <button onclick="filterGallery('Portraits')">Portraits</button>
            <button onclick="filterGallery('Events')">Events</button>
            <button onclick="filterGallery('Artistic')">Artistic</button>
        </div>
        <div class="gallery-grid">
            <?php
            $result = $conn->query("SELECT * FROM gallery_images");
            while ($row = $result->fetch_assoc()) {
                echo "
                <div class='gallery-item' data-category='{$row['category']}'>
                    <img src='{$row['image_path']}' alt='{$row['category']}'>
                </div>";
            }
            ?>
        </div>
    </section>
    <?php include('includes/footer.php'); ?>
</body>
</html>
