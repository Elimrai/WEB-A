<?php include('db_config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Experience & Skills</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>
    <section class="experience">
        <h1>Experience & Skills</h1>
        <div class="timeline">
            <?php
            $result = $conn->query("SELECT * FROM skills_and_experience");
            while ($row = $result->fetch_assoc()) {
                echo "<div class='timeline-item'>
                        <p>{$row['content']}</p>
                      </div>";
            }
            ?>
        </div>
        <div class="skills">
            <h2>Skills</h2>
            <div class="skill-badges">
                <span class="badge">Portrait Photography</span>
                <span class="badge">Event Photography</span>
                <span class="badge">Editing Mastery</span>
                <span class="badge">Artistic Vision</span>
            </div>
        </div>
    </section>
    <?php include('includes/footer.php'); ?>
</body>
</html>
