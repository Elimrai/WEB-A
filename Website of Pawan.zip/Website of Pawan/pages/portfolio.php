<?php include('db_config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>
    <section class="portfolio">
        <h1>My Portfolio</h1>
        <div class="portfolio-grid">
            <?php
            $result = $conn->query("SELECT * FROM portfolio_items");
            while ($row = $result->fetch_assoc()) {
                echo "
                <div class='portfolio-item'>
                    <img src='{$row['image_path']}' alt='{$row['title']}'>
                    <div class='overlay'>
                        <h3>{$row['title']}</h3>
                        <p>{$row['description']}</p>
                    </div>
                </div>";
            }
            ?>
        </div>
    </section>
    <?php include('includes/footer.php'); ?>
</body>
</html>
