<?php include('includes/header.php'); ?>
<section class="hero">
    <h1>Welcome to My Photography Portfolio</h1>
    <p>Explore my world of photography through stunning visuals and creative storytelling.</p>
</section>
<section class="featured-portfolio">
    <h2>Featured Projects</h2>
    <div class="grid">
        <?php
        include('db_config.php');
        $result = $conn->query("SELECT * FROM portfolio_items LIMIT 4");
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card'>
                    <img src='{$row['image_path']}' alt='{$row['title']}'>
                    <h3>{$row['title']}</h3>
                    <p>{$row['description']}</p>
                </div>";
        }
        ?>
    </div>
</section>
<?php include('includes/footer.php'); ?>
